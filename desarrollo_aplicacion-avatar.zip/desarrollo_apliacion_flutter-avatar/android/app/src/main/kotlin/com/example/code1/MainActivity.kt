package com.example.code1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
